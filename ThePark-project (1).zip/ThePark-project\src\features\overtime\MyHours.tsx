import { useEffect, useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../../lib/axios';
import { AuthPhoto, CameraDialog, DaysGrid, PhotoDialog, SessionList, WeekNav, WeekTotals, apiError, useNow, useSignOut, useToast, useWeek } from './components';
import { useAuthStore } from '../../store/useAuthStore';
import { MONTHS_LONG, WEEKDAYS_LONG, fmtClock, fmtDur, hm, sessMs, type OvertimeSession } from './overtimeUtils';

/** Met een code: na in- of uitklokken het bedank-/succesbericht zo lang tonen, dan terug naar het codescherm. */
const CODE_DONE_MS = 8000;

interface Farewell {
  kind: 'start' | 'stop';
  title: string;
  text: string;
}

interface MineResponse {
  week: string;
  current: OvertimeSession | null;
  sessions: OvertimeSession[];
}

/** Werknemer: in- en uitklokken voor overuren en de eigen week bekijken. */
export default function MyHours() {
  const now = useNow();
  const toast = useToast();
  const queryClient = useQueryClient();
  const { monday, week, shift } = useWeek();
  const [camOpen, setCamOpen] = useState(false);
  const [photoOf, setPhotoOf] = useState<OvertimeSession | null>(null);
  const viaCode = useAuthStore((s) => s.viaCode);
  const signOut = useSignOut();
  // Cancelled on unmount, so a pending sign-out can't hit the next colleague who already typed their code.
  const doneTimer = useRef<ReturnType<typeof setTimeout>>();
  useEffect(() => () => clearTimeout(doneTimer.current), []);
  const [farewell, setFarewell] = useState<Farewell | null>(null);
  // Code session: show a full-screen message, then hand the phone back to the code screen.
  // Employer session: a toast is enough, they stay on their page.
  const finish = (f: Farewell) => {
    if (!viaCode) {
      toast(`${f.title} ${f.text}`);
      return;
    }
    setFarewell(f);
    clearTimeout(doneTimer.current);
    doneTimer.current = setTimeout(signOut, CODE_DONE_MS);
  };

  const { data, isLoading, isError } = useQuery({
    queryKey: ['overtime', 'me', week],
    queryFn: async () => (await api.get<MineResponse>('/overtime/me', { params: { week } })).data,
  });
  const refresh = () => queryClient.invalidateQueries({ queryKey: ['overtime'] });

  const start = useMutation({
    mutationFn: (photo: string) => api.post('/overtime/start', { photo }),
    onSuccess: () => {
      setCamOpen(false);
      refresh();
      finish({ kind: 'start', title: 'Veel succes met werken!', text: 'Je tijd loopt. Typ straks weer je code en druk op "Stop met werken".' });
    },
    onError: (e) => toast(apiError(e, 'Inklokken is niet gelukt. Controleer je verbinding en probeer opnieuw.')),
  });

  const stop = useMutation({
    mutationFn: async () => (await api.post<{ session: OvertimeSession }>('/overtime/stop')).data.session,
    onSuccess: (s) => {
      refresh();
      finish({ kind: 'stop', title: 'Bedankt om te werken bij The Park!', text: `Je hebt ${fmtDur(sessMs(s, Date.now()))} overuren gewerkt. Die zijn opgeslagen.` });
    },
    onError: (e) => toast(apiError(e, 'Uitklokken is niet gelukt. Probeer het opnieuw.')),
  });

  if (isLoading) return <p className="ot-note">Even laden…</p>;
  if (isError || !data) return <div className="ot-notice error">Je uren konden niet geladen worden. Probeer de pagina te vernieuwen.</div>;

  if (farewell) {
    return (
      <section className={`ot-farewell ${farewell.kind}`} role="status" aria-live="polite">
        <div className="ot-farewell-icon" aria-hidden="true">{farewell.kind === 'stop' ? '♥' : '✓'}</div>
        <h2>{farewell.title}</h2>
        <p>{farewell.text}</p>
        <button className="ot-bigbtn" type="button" onClick={signOut}>Klaar</button>
        <p className="ot-note">Je gaat zo vanzelf terug naar het codescherm.</p>
      </section>
    );
  }

  const open = data.current;
  const today = new Date(now);

  return (
    <>
      <section className="ot-clock">
        {open ? (
          <>
            <div className="ot-dial live">
              {open.has_photo ? <AuthPhoto sessionId={open.id} alt="Je foto bij inklokken" /> : null}
              <div className="ot-timer">{fmtClock(sessMs(open, now))}</div>
              <small>sinds {hm(new Date(open.start_time))}</small>
            </div>
            <button className="ot-bigbtn stop" type="button" onClick={() => stop.mutate()} disabled={stop.isPending}>
              Stop met werken
            </button>
          </>
        ) : (
          <>
            <p className="ot-when">{WEEKDAYS_LONG[today.getDay()]} {today.getDate()} {MONTHS_LONG[today.getMonth()]}</p>
            <div className="ot-dial"><div className="ot-timer">00:00:00</div></div>
            <button className="ot-bigbtn" type="button" onClick={() => setCamOpen(true)}>Start met werken</button>
            <p className="ot-note">Bij het starten maak je een foto voor je leidinggevende.</p>
          </>
        )}
      </section>

      <WeekNav monday={monday} onShift={shift} />
      <DaysGrid monday={monday} sessions={data.sessions} now={now} />
      <WeekTotals sessions={data.sessions} now={now} />
      <SessionList sessions={data.sessions} now={now} onPhoto={setPhotoOf} />

      {camOpen && <CameraDialog onCancel={() => setCamOpen(false)} onConfirm={async (p) => { await start.mutateAsync(p).catch(() => {}); }} />}
      {photoOf && <PhotoDialog session={photoOf} onClose={() => setPhotoOf(null)} />}
    </>
  );
}
