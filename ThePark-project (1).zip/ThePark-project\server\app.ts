import express from 'express';
import authRoutes from './routes/authRoutes.js';
import overtimeRoutes from './routes/overtimeRoutes.js';
import logger from './utils/logger.js';

const app = express();

// Trust reverse proxies (e.g., Nginx, AWS ELB) to securely populate req.ip from X-Forwarded-For
app.set('trust proxy', 1);

// Middleware
// Overuren-routes ontvangen een foto (base64) bij het inklokken, dus een ruimere limiet.
app.use('/api/overtime', express.json({ limit: '3mb' }));
app.use(express.json());

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'ThePark API is running' });
});

app.use('/api/auth', authRoutes);
app.use('/api/overtime', overtimeRoutes);

// Global Error Middleware
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    logger.error('Unhandled Server Error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

export default app;
