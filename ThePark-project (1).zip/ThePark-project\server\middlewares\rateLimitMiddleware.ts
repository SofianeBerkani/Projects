/**
 * 🛡️ SECURITY: Rate limiting for the login endpoints (brute force protection).
 * In-memory fixed window per IP; expired entries are purged every 10 minutes.
 */

import { Request, Response, NextFunction } from 'express';

interface RateLimitEntry {
    count: number;
    resetAt: number; // Unix timestamp in ms
}

const loginAttempts = new Map<string, RateLimitEntry>();
const codeAttempts = new Map<string, RateLimitEntry>();

const rateLimiterInterval = setInterval(() => {
    const now = Date.now();
    for (const store of [loginAttempts, codeAttempts]) {
        for (const [key, entry] of store.entries()) {
            if (entry.resetAt < now) store.delete(key);
        }
    }
}, 10 * 60 * 1000);
rateLimiterInterval.unref();

function createRateLimiter(store: Map<string, RateLimitEntry>, maxAttempts: number, windowMs: number, message: string) {
    return (req: Request, res: Response, next: NextFunction): void => {
        if (process.env.NODE_ENV === 'test') {
            return next();
        }

        // req.ip is populated securely by Express when trust proxy is set
        const ip = req.ip || 'unknown';
        const now = Date.now();
        const entry = store.get(ip);

        if (!entry || entry.resetAt < now) {
            store.set(ip, { count: 1, resetAt: now + windowMs });
            return next();
        }

        if (entry.count >= maxAttempts) {
            const retryAfterSeconds = Math.ceil((entry.resetAt - now) / 1000);
            res.setHeader('Retry-After', retryAfterSeconds);
            res.status(429).json({ error: message, retryAfter: retryAfterSeconds });
            return;
        }

        entry.count++;
        next();
    };
}

/** Werkgever: 10 pogingen per 15 minuten per IP. */
export const loginRateLimiter = createRateLimiter(
    loginAttempts,
    10,
    15 * 60 * 1000,
    'Te veel pogingen. Probeer het over een paar minuten opnieuw.'
);

/** Werknemerscode: 20 pogingen per 15 minuten per IP. Codes zijn 6 cijfers, dus raden blijft onbegonnen werk. */
export const codeRateLimiter = createRateLimiter(
    codeAttempts,
    20,
    15 * 60 * 1000,
    'Te veel pogingen. Probeer het over een paar minuten opnieuw.'
);
