import { Response } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import db from '../db/index.js';
import { AuthRequest } from '../middlewares/authMiddleware.js';
import logger from '../utils/logger.js';
import { logAudit } from '../services/auditService.js';

// Foto's staan bewust NIET in public/uploads: ze zijn alleen via de API op te vragen
// door de werkgever (manager) of de werknemer zelf.
export const PHOTO_DIR = path.join(process.cwd(), 'storage', 'overtime-photos');
const MAX_PHOTO_BYTES = 1.5 * 1024 * 1024;
const JPEG_DATA_URL = /^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/;
const WEEK_RE = /^\d{4}-W\d{2}$/;

const APP_TIMEZONE = process.env.APP_TIMEZONE || 'Europe/Brussels';
const dayFormatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: APP_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
});

const pad = (n: number) => String(n).padStart(2, '0');

/** 'YYYY-MM-DD' of the given instant in the company timezone. */
export const dayKey = (d: Date): string => dayFormatter.format(d);

/** ISO week ('YYYY-Www') of a 'YYYY-MM-DD' calendar day. */
export const isoWeekOfDay = (day: string): string => {
    const [y, m, d] = day.split('-').map(Number);
    const t = new Date(Date.UTC(y, m - 1, d));
    const wd = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - wd);
    const year = t.getUTCFullYear();
    const week = Math.ceil(((t.getTime() - Date.UTC(year, 0, 1)) / 864e5 + 1) / 7);
    return `${year}-W${pad(week)}`;
};

const currentWeek = () => isoWeekOfDay(dayKey(new Date()));
const weekParam = (req: AuthRequest): string => {
    const w = String(req.query.week || '');
    return WEEK_RE.test(w) ? w : currentWeek();
};

// Statements are prepared on first use: the table is created by initDb(), which runs after this module loads.
const lazy = <T>(make: () => T) => { let v: T | undefined; return () => (v ??= make()); };

const SESSION_COLS = `id, user_id, start_time, end_time, day, week, status, reviewed_at,
    CASE WHEN photo_path IS NULL THEN 0 ELSE 1 END AS has_photo`;

const stmtOpenByUser = lazy(() => db.prepare(`SELECT ${SESSION_COLS} FROM overtime_sessions WHERE user_id = ? AND end_time IS NULL`));
const stmtWeekByUser = lazy(() => db.prepare(`SELECT ${SESSION_COLS} FROM overtime_sessions WHERE user_id = ? AND week = ? ORDER BY start_time DESC`));
const stmtWeekAll = lazy(() => db.prepare(`SELECT ${SESSION_COLS} FROM overtime_sessions WHERE week = ? ORDER BY start_time DESC`));
const stmtOpenAll = lazy(() => db.prepare(`SELECT user_id, start_time FROM overtime_sessions WHERE end_time IS NULL`));
const stmtInsert = lazy(() => db.prepare(`INSERT INTO overtime_sessions (user_id, start_time, day, week, photo_path) VALUES (?, ?, ?, ?, ?)`));
const stmtStop = lazy(() => db.prepare(`UPDATE overtime_sessions SET end_time = ? WHERE id = ? RETURNING ${SESSION_COLS}`));
const stmtById = lazy(() => db.prepare(`SELECT id, user_id, photo_path FROM overtime_sessions WHERE id = ?`));
const stmtReview = lazy(() => db.prepare(`UPDATE overtime_sessions SET status = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ? RETURNING ${SESSION_COLS}`));
const stmtTeam = lazy(() => db.prepare(`SELECT id, name FROM users WHERE role = 'employee' OR (role != 'manager' AND id IN (SELECT user_id FROM overtime_sessions WHERE week = ?)) ORDER BY name COLLATE NOCASE`));

export const getMine = (req: AuthRequest, res: Response): void => {
    try {
        const userId = req.user!.id;
        res.json({
            week: weekParam(req),
            current: stmtOpenByUser().get(userId) || null,
            sessions: stmtWeekByUser().all(userId, weekParam(req)),
        });
    } catch (error) {
        logger.error('Overtime getMine error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

export const startWork = (req: AuthRequest, res: Response): void => {
    const userId = req.user!.id;
    if (stmtOpenByUser().get(userId)) {
        res.status(409).json({ error: 'Je bent al aan het werk. Stop eerst met werken.' });
        return;
    }

    const match = typeof req.body?.photo === 'string' ? JPEG_DATA_URL.exec(req.body.photo) : null;
    const buffer = match ? Buffer.from(match[1], 'base64') : null;
    if (!buffer || buffer.length < 3 || buffer[0] !== 0xff || buffer[1] !== 0xd8 || buffer.length > MAX_PHOTO_BYTES) {
        res.status(400).json({ error: 'Er is een geldige foto nodig om te starten met werken.' });
        return;
    }

    let fileName: string | null = null;
    try {
        fs.mkdirSync(PHOTO_DIR, { recursive: true });
        fileName = `${userId}-${Date.now()}-${crypto.randomBytes(6).toString('hex')}.jpg`;
        fs.writeFileSync(path.join(PHOTO_DIR, fileName), buffer);

        const now = new Date();
        const day = dayKey(now);
        const info = stmtInsert().run(userId, now.toISOString(), day, isoWeekOfDay(day), fileName);
        res.status(201).json({ current: stmtOpenByUser().get(userId), sessionId: Number(info.lastInsertRowid) });
    } catch (error: any) {
        if (fileName) fs.unlink(path.join(PHOTO_DIR, fileName), () => {});
        if (error?.code === 'SQLITE_CONSTRAINT_UNIQUE') {
            res.status(409).json({ error: 'Je bent al aan het werk. Stop eerst met werken.' });
            return;
        }
        logger.error('Overtime start error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

export const stopWork = (req: AuthRequest, res: Response): void => {
    try {
        const open = stmtOpenByUser().get(req.user!.id) as { id: number } | undefined;
        if (!open) {
            res.status(409).json({ error: 'Je bent niet aan het werk.' });
            return;
        }
        res.json({ session: stmtStop().get(new Date().toISOString(), open.id) });
    } catch (error) {
        logger.error('Overtime stop error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

export const getTeam = (req: AuthRequest, res: Response): void => {
    try {
        const week = weekParam(req);
        const openByUser = new Map<number, string>();
        for (const row of stmtOpenAll().all() as { user_id: number; start_time: string }[]) {
            openByUser.set(row.user_id, row.start_time);
        }
        const sessionsByUser = new Map<number, any[]>();
        for (const s of stmtWeekAll().all(week) as any[]) {
            let list = sessionsByUser.get(s.user_id);
            if (!list) sessionsByUser.set(s.user_id, (list = []));
            list.push(s);
        }
        const employees = (stmtTeam().all(week) as { id: number; name: string }[]).map((u) => ({
            id: u.id,
            name: u.name,
            openSince: openByUser.get(u.id) || null,
            sessions: sessionsByUser.get(u.id) || [],
        }));
        res.json({ week, employees });
    } catch (error) {
        logger.error('Overtime getTeam error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

export const reviewSession = (req: AuthRequest, res: Response): void => {
    try {
        const { status } = req.body || {};
        if (status !== 'approved' && status !== 'rejected' && status !== 'pending') {
            res.status(400).json({ error: 'Ongeldige status.' });
            return;
        }
        const reviewedAt = status === 'pending' ? null : new Date().toISOString();
        const reviewer = status === 'pending' ? null : req.user!.id;
        const session = stmtReview().get(status, reviewer, reviewedAt, Number(req.params.id));
        if (!session) {
            res.status(404).json({ error: 'Registratie niet gevonden.' });
            return;
        }
        res.json({ session });
    } catch (error) {
        logger.error('Overtime review error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

export const deleteSession = (req: AuthRequest, res: Response): void => {
    try {
        const row = stmtById().get(Number(req.params.id)) as { id: number; user_id: number; photo_path: string | null } | undefined;
        if (!row) {
            res.status(404).json({ error: 'Registratie niet gevonden.' });
            return;
        }
        db.prepare('DELETE FROM overtime_sessions WHERE id = ?').run(row.id);
        if (row.photo_path) fs.unlink(path.join(PHOTO_DIR, path.basename(row.photo_path)), () => {});
        logAudit('overtime_sessions', row.id, 'DELETE', req.user!.id, { user_id: row.user_id }, null);
        res.json({ message: 'Registratie verwijderd.' });
    } catch (error) {
        logger.error('Overtime delete error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

export const getPhoto = (req: AuthRequest, res: Response): void => {
    try {
        const row = stmtById().get(Number(req.params.id)) as { user_id: number; photo_path: string | null } | undefined;
        if (!row || !row.photo_path) {
            res.status(404).json({ error: 'Geen foto gevonden.' });
            return;
        }
        if (req.user!.role !== 'manager' && req.user!.id !== row.user_id) {
            res.status(403).json({ error: 'Forbidden: Insufficient permissions' });
            return;
        }
        const filePath = path.join(PHOTO_DIR, path.basename(row.photo_path));
        if (!fs.existsSync(filePath)) {
            res.status(404).json({ error: 'Geen foto gevonden.' });
            return;
        }
        res.setHeader('Cache-Control', 'private, no-store');
        res.type('image/jpeg').sendFile(filePath);
    } catch (error) {
        logger.error('Overtime photo error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
