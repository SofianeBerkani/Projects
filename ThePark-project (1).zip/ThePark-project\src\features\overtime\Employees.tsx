import React, { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../../lib/axios';
import { apiError, useToast } from './components';

interface Account {
  id: number;
  name: string;
  active: boolean;
  hasCode: boolean;
  /** Current personal code, readable by the employer only. */
  code: string | null;
}

interface EmployeesResponse {
  max: number;
  active: number;
  employees: Account[];
}

/** Werkgever: werknemers toevoegen (max. 5), hun persoonlijke code tonen/vernieuwen en toegang beheren. */
export default function Employees() {
  const toast = useToast();
  const queryClient = useQueryClient();
  const [name, setName] = useState('');
  // Highlight a freshly made code at the top; it also stays visible in the list below.
  const [shownCode, setShownCode] = useState<{ name: string; code: string } | null>(null);

  const { data, isLoading, isError } = useQuery({
    queryKey: ['overtime', 'employees'],
    queryFn: async () => (await api.get<EmployeesResponse>('/overtime/employees')).data,
  });
  const refresh = () => queryClient.invalidateQueries({ queryKey: ['overtime'] });

  const create = useMutation({
    mutationFn: async () => (await api.post<{ code: string }>('/overtime/employees', { name })).data,
    onSuccess: (r) => {
      setShownCode({ name: name.trim(), code: r.code });
      setName('');
      refresh();
    },
    onError: (e) => toast(apiError(e, 'Werknemer toevoegen is niet gelukt.')),
  });

  const newCode = useMutation({
    mutationFn: async (a: Account) => (await api.post<{ code: string }>(`/overtime/employees/${a.id}/code`)).data,
    onSuccess: (r, a) => {
      setShownCode({ name: a.name, code: r.code });
      refresh();
    },
    onError: (e) => toast(apiError(e, 'Nieuwe code maken is niet gelukt.')),
  });

  const access = useMutation({
    mutationFn: (a: Account) => api.patch(`/overtime/employees/${a.id}/access`, { active: !a.active }),
    onSuccess: (_r, a) => {
      toast(a.active ? `Toegang van ${a.name} is ingetrokken.` : `${a.name} heeft weer toegang.`);
      refresh();
    },
    onError: (e) => toast(apiError(e, 'Opslaan is niet gelukt.')),
  });

  if (isLoading) return <p className="ot-note">Even laden…</p>;
  if (isError || !data) return <div className="ot-notice error">De werknemers konden niet geladen worden. Probeer de pagina te vernieuwen.</div>;

  const full = data.active >= data.max;
  const onCreate = (e: React.FormEvent) => {
    e.preventDefault();
    create.mutate();
  };

  return (
    <>
      {shownCode && (
        <div className="ot-notice ot-codebox" role="status">
          <div className="ot-sub">Persoonlijke code van {shownCode.name}</div>
          <strong className="ot-codeshow">{shownCode.code}</strong>
          <p className="ot-note" style={{ margin: 0 }}>
            Geef deze code aan {shownCode.name}. Je vindt hem ook altijd terug in de lijst hieronder.
          </p>
          <div className="ot-row">
            <button className="ot-btn primary" type="button" onClick={() => setShownCode(null)}>Oké</button>
          </div>
        </div>
      )}

      <div className="ot-weektotal">
        <div>
          <div className="ot-sub">Werknemers met toegang</div>
          <strong>{data.active} van {data.max}</strong>
        </div>
      </div>

      {data.employees.length ? (
        <ul className="ot-sessions" style={{ marginBottom: '1.5rem' }}>
          {data.employees.map((a) => (
            <li key={a.id} className="ot-sess" style={{ gridTemplateColumns: '1fr auto' }}>
              <div>
                <div className="t">{a.name}</div>
                {a.code ? (
                  <div className="ot-rowcode">Code: <b>{a.code}</b></div>
                ) : a.hasCode ? (
                  <div className="d">Deze code is van vóór de update en kan niet getoond worden. Druk op <b>Nieuwe code</b>, dan staat de code hier.</div>
                ) : null}
                <span className={`ot-badge${a.active ? ' ok' : ' no'}`}>{a.active ? 'Heeft toegang' : 'Geen toegang'}</span>
                {!a.hasCode && <span className="ot-badge" style={{ marginLeft: '.4rem' }}>Nog geen code</span>}
              </div>
              <div className="ot-actions" style={{ gridColumn: '1 / -1' }}>
                <button type="button" className={a.hasCode && !a.code ? "on-ok" : ""} onClick={() => newCode.mutate(a)} disabled={newCode.isPending}>
                  {a.hasCode ? 'Nieuwe code' : 'Code maken'}
                </button>
                <button type="button" onClick={() => access.mutate(a)} disabled={access.isPending || (!a.active && full)}>
                  {a.active ? 'Toegang intrekken' : 'Toegang geven'}
                </button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="ot-empty" style={{ marginBottom: '1.5rem' }}>Nog geen werknemers. Voeg hieronder je eerste werknemer toe.</p>
      )}

      <h2>Werknemer toevoegen</h2>
      {full ? (
        <div className="ot-notice" style={{ marginTop: '1rem' }}>
          Je hebt het maximum van <b>{data.max} werknemers</b> bereikt. Trek eerst de toegang van iemand in om een nieuwe werknemer toe te voegen.
        </div>
      ) : (
        <form className="ot-dialog" style={{ width: '100%', marginTop: '1rem', border: '1px solid var(--ot-line)' }} onSubmit={onCreate}>
          <label className="ot-field">
            Naam
            <input required maxLength={80} value={name} onChange={(e) => setName(e.target.value)} autoComplete="off" />
          </label>
          <p className="ot-note" style={{ margin: 0 }}>De werknemer krijgt meteen een persoonlijke code van 6 cijfers om mee in te klokken.</p>
          <div className="ot-row">
            <button className="ot-btn primary" type="submit" disabled={create.isPending}>Werknemer toevoegen</button>
          </div>
        </form>
      )}
    </>
  );
}
