# ThePark – Overuren

Een app voor de telefoon waarmee werknemers van The Park hun **overuren** in- en uitklokken, met een foto als bewijs. De werkgever controleert de uren per dag en per week en keurt ze goed of af.

## Wat kan de app?

**Werknemer**
- **Start met werken**: er wordt een selfie gemaakt en je krijgt de melding "Veel succes met werken!".
- De tijd loopt zichtbaar door tot je op **Stop met werken** drukt.
- Je ziet je eigen overuren per dag en per week.

**Werkgever (beheerder)**
- **Overzicht werknemers**: wie er nu werkt, uren per dag en per week, foto's, goedkeuren of afkeuren.
- **Werknemers**: accounts aanmaken (maximaal 5), toegang intrekken of teruggeven, wachtwoorden wijzigen.

Alleen de werkgever maakt accounts aan. Zelf een account aanmaken kan niet.

## Starten

Nodig: [Node.js](https://nodejs.org) (LTS).

Maak in de projectmap een bestand `.env` met deze inhoud (vul zelf de twee geheimen in):

```ini
NODE_ENV="development"
PORT=3000
DB_PATH="ThePark.db"
JWT_SECRET="een-lange-willekeurige-tekst"
ADMIN_NAME="Werkgever"
ADMIN_EMAIL="admin@thepark.com"
ADMIN_PASSWORD="kies-een-sterk-wachtwoord"
MAX_EMPLOYEES=5
APP_TIMEZONE="Europe/Brussels"
```

Daarna:

```bash
npm install
npm run dev
```

Open daarna http://localhost:3000. Bij de eerste start wordt het werkgeversaccount aangemaakt met `ADMIN_EMAIL` en `ADMIN_PASSWORD` uit `.env`.

### Op je telefoon openen
1. Zorg dat je telefoon op hetzelfde wifi-netwerk zit als de computer.
2. Zoek het IP-adres van je computer op (Windows: `ipconfig`, bij "IPv4-adres").
3. Open op je telefoon `http://<IP-adres>:3000`.
4. Kies in je browser **"Toevoegen aan beginscherm"**. Dan opent ThePark als een app.

Via een gewoon `http://`-adres staat de browser geen livecamera toe. De app laat dan de knop **"Foto maken"** zien, die de camera van de telefoon opent. Wil je de livecamera, zet de app dan online met **https**.

## Instellingen (`.env`)

| Instelling | Betekenis |
| --- | --- |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Inloggegevens van de werkgever (alleen bij de eerste start) |
| `JWT_SECRET` | Geheime sleutel voor het inloggen, kies een lange willekeurige tekst |
| `MAX_EMPLOYEES` | Maximaal aantal werknemers met toegang (standaard 5) |
| `APP_TIMEZONE` | Tijdzone waarin per dag/week geteld wordt (standaard `Europe/Brussels`) |
| `DB_PATH` | Databasebestand (standaard `ThePark.db`) |

Foto's worden bewaard in `storage/overtime-photos/` en zijn alleen zichtbaar voor de werkgever en de werknemer zelf.

## Voor ontwikkelaars

- Web-app: React + Vite (`src/features/overtime/`)
- Server: Node.js + Express + SQLite (`server/`, overuren-API in `server/controllers/overtimeController.ts` en `teamController.ts`)
- Tests: `npm test`
