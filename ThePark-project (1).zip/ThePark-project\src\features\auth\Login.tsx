import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import { useAuthStore } from '../../store/useAuthStore';
import api from '../../lib/axios';
import { ParkHeader } from '../overtime/OvertimeLayout';
import '../overtime/overtime.css';

const errorOf = (e: unknown) => {
  const data = (e as any)?.response?.data;
  if (data?.error === 'Account suspended') return `Account geblokkeerd: ${data.suspension_reason}`;
  if (data?.error === 'Invalid credentials') return 'E-mail of wachtwoord is niet juist.';
  if (!data?.error || /Internal server error|Too many/i.test(data.error)) return 'Er ging iets mis. Probeer het zo opnieuw.';
  return data.error;
};

/** Werknemers typen hun persoonlijke code; de werkgever logt in met e-mail en wachtwoord. */
export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const login = useAuthStore((state) => state.login);

  const [mode, setMode] = useState<'code' | 'employer'>('code');
  const [code, setCode] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const codeMutation = useMutation({
    mutationFn: async (c: string) => (await api.post('/auth/code', { code: c })).data,
    onSuccess: (data) => {
      login(data.user, data.token, undefined, true);
      navigate('/', { replace: true });
    },
    onError: () => setCode(''),
  });

  const employerMutation = useMutation({
    mutationFn: async () => (await api.post('/auth/login', { email, password })).data,
    onSuccess: (data) => {
      login(data.user, data.token, data.serverTime);
      navigate(location.state?.from?.pathname || '/', { replace: true });
    },
  });

  const onCodeChange = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 6);
    setCode(digits);
    if (digits.length === 6 && !codeMutation.isPending) codeMutation.mutate(digits);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'employer') employerMutation.mutate();
    else if (code.length === 6) codeMutation.mutate(code);
  };

  const switchMode = () => {
    codeMutation.reset();
    employerMutation.reset();
    setMode(mode === 'code' ? 'employer' : 'code');
  };

  const active = mode === 'code' ? codeMutation : employerMutation;

  return (
    <div className="ot">
      <div className="ot-login">
        <form className="ot-login-card" onSubmit={submit}>
          <div className="ot-login-head"><ParkHeader /></div>

          {mode === 'code' ? (
            <>
              <h2>Typ je persoonlijke code</h2>
              {active.isError && <div className="ot-notice error">{errorOf(active.error)}</div>}
              <label className="ot-field">
                <span className="ot-sr">Persoonlijke code</span>
                <input
                  className="ot-code"
                  value={code}
                  onChange={(e) => onCodeChange(e.target.value)}
                  inputMode="numeric"
                  pattern="\d{6}"
                  maxLength={6}
                  autoComplete="off"
                  autoFocus
                  placeholder="••••••"
                  aria-label="Persoonlijke code van 6 cijfers"
                  disabled={codeMutation.isPending}
                />
              </label>
              <button className="ot-bigbtn" type="submit" disabled={code.length !== 6 || codeMutation.isPending} style={{ minWidth: 0 }}>
                {codeMutation.isPending ? 'Even geduld…' : 'Verder'}
              </button>
              <p className="ot-note" style={{ margin: 0, textAlign: 'center' }}>
                Je code van 6 cijfers krijg je van je werkgever.
              </p>
            </>
          ) : (
            <>
              <h2>Inloggen als werkgever</h2>
              {active.isError && <div className="ot-notice error">{errorOf(active.error)}</div>}
              <label className="ot-field">
                E-mail
                <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" dir="ltr" />
              </label>
              <label className="ot-field">
                Wachtwoord
                <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" dir="ltr" />
              </label>
              <button className="ot-bigbtn" type="submit" disabled={employerMutation.isPending} style={{ minWidth: 0 }}>
                {employerMutation.isPending ? 'Even geduld…' : 'Inloggen'}
              </button>
            </>
          )}

          <p className="ot-note" style={{ margin: 0, textAlign: 'center' }}>
            <button type="button" className="ot-switch" onClick={switchMode}>
              {mode === 'code' ? 'Werkgever? Log hier in' : 'Terug naar code invoeren'}
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}
