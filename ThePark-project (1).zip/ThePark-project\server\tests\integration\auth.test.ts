import request from 'supertest';
import bcrypt from 'bcryptjs';
import app from '../../app.js';
import db, { initDb } from '../../db/index.js';

beforeAll(async () => {
  initDb();
  const hash = await bcrypt.hash('geheim123', 10);
  const insert = db.prepare(`INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)`);
  insert.run('Werkgever', 'baas_auth@test.com', hash, 'manager');
  insert.run('Werknemer', 'werknemer_auth@test.com', hash, 'employee');
});

afterAll(() => {
  db.close();
});

/**
 * @scenario Werkgever logt in met e-mail en wachtwoord; werknemers alleen met hun code.
 */
describe('Auth API', () => {
  it('logs the employer in with e-mail and password', async () => {
    const res = await request(app).post('/api/auth/login').send({ email: 'BAAS_auth@test.com', password: 'geheim123' });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('token');
    expect(res.body.user).toMatchObject({ name: 'Werkgever', role: 'manager' });
  });

  it('gives the same error for a wrong password and an unknown e-mail', async () => {
    const wrong = await request(app).post('/api/auth/login').send({ email: 'baas_auth@test.com', password: 'fout' });
    const unknown = await request(app).post('/api/auth/login').send({ email: 'niemand@test.com', password: 'fout' });
    expect(wrong.status).toBe(401);
    expect(unknown.status).toBe(401);
    expect(wrong.body.error).toBe(unknown.body.error);
  });

  it('sends employees to their personal code instead', async () => {
    const res = await request(app).post('/api/auth/login').send({ email: 'werknemer_auth@test.com', password: 'geheim123' });
    expect(res.status).toBe(403);
    expect(res.body.error).toContain('persoonlijke code');
  });

  it('requires e-mail and password', async () => {
    expect((await request(app).post('/api/auth/login').send({})).status).toBe(400);
  });

  it('has no self sign-up anymore', async () => {
    expect((await request(app).post('/api/auth/register').send({ name: 'x', email: 'x@test.com', password: 'geheim123' })).status).toBe(404);
  });

  it('rejects requests without a valid token', async () => {
    expect((await request(app).get('/api/overtime/team')).status).toBe(401);
    expect((await request(app).get('/api/overtime/team').set('Authorization', 'Bearer nep')).status).toBe(401);
  });
});
