import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../../lib/axios';
import { DaysGrid, PhotoDialog, SessionList, WeekNav, WeekTotals, apiError, useNow, useToast, useWeek } from './components';
import { fmtClock, fmtDur, sumMs, type OvertimeSession, type TeamMember } from './overtimeUtils';

/** Werkgever: overuren van alle werknemers per week, met foto's en goed-/afkeuren. */
export default function TeamOverview() {
  const now = useNow();
  const toast = useToast();
  const queryClient = useQueryClient();
  const { monday, week, shift } = useWeek();
  const [expanded, setExpanded] = useState<number | null>(null);
  const [photoOf, setPhotoOf] = useState<{ session: OvertimeSession; name: string } | null>(null);

  const { data, isLoading, isError } = useQuery({
    queryKey: ['overtime', 'team', week],
    queryFn: async () => (await api.get<{ week: string; employees: TeamMember[] }>('/overtime/team', { params: { week } })).data,
    refetchInterval: 15000,
  });

  const review = useMutation({
    mutationFn: ({ id, status }: { id: number; status: OvertimeSession['status'] }) =>
      api.patch(`/overtime/sessions/${id}/review`, { status }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['overtime'] }),
    onError: (e) => toast(apiError(e, 'Beoordeling opslaan is niet gelukt.')),
  });

  const remove = useMutation({
    mutationFn: (s: OvertimeSession) => api.delete(`/overtime/sessions/${s.id}`),
    onSuccess: () => {
      toast('Registratie verwijderd.');
      queryClient.invalidateQueries({ queryKey: ['overtime'] });
    },
    onError: (e) => toast(apiError(e, 'Verwijderen is niet gelukt.')),
  });

  // Clicking the active choice again undoes it, like in the original app.
  const onReview = (s: OvertimeSession, status: 'approved' | 'rejected') =>
    review.mutate({ id: s.id, status: s.status === status ? 'pending' : status });

  return (
    <>
      <WeekNav monday={monday} onShift={shift} first />
      {isLoading && <p className="ot-note">Even laden…</p>}
      {isError && <div className="ot-notice error">Het overzicht kon niet geladen worden. Probeer de pagina te vernieuwen.</div>}
      {data && !data.employees.length && (
        <div className="ot-notice">
          Nog geen werknemers. Voeg ze toe onder het tabblad <b>Werknemers</b> (maximaal 5).
        </div>
      )}
      {data && data.employees.length > 0 && (
        <ul className="ot-emps">
          {data.employees.map((e) => {
            const tot = sumMs(e.sessions, now);
            const isOpen = expanded === e.id;
            return (
              <li key={e.id}>
                <button className="ot-emp" type="button" aria-expanded={isOpen} onClick={() => setExpanded(isOpen ? null : e.id)}>
                  <span className={`dot${e.openSince ? ' live' : ''}`} />
                  <span className="name">{e.name || 'Werknemer'}</span>
                  <span className={`state${e.openSince ? ' live' : ''}`}>
                    {e.openSince
                      ? `Aan het werk, ${fmtClock(now - Date.parse(e.openSince))}`
                      : e.sessions.length
                        ? `${e.sessions.length} registratie${e.sessions.length > 1 ? 's' : ''}`
                        : 'Geen overuren deze week'}
                  </span>
                  <span className="tot">{fmtDur(tot)}</span>
                </button>
                {isOpen && (
                  <div className="ot-detail">
                    <DaysGrid monday={monday} sessions={e.sessions} now={now} />
                    <WeekTotals sessions={e.sessions} now={now} />
                    <SessionList
                      sessions={e.sessions}
                      now={now}
                      onPhoto={(s) => setPhotoOf({ session: s, name: e.name })}
                      onReview={onReview}
                      onDelete={(s) => remove.mutate(s)}
                    />
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
      {photoOf && <PhotoDialog session={photoOf.session} name={photoOf.name} onClose={() => setPhotoOf(null)} />}
    </>
  );
}
