import request from 'supertest';
import fs from 'fs';
import path from 'path';
import app from '../../app.js';
import db, { initDb } from '../../db/index.js';
import jwt from 'jsonwebtoken';
import { PHOTO_DIR, isoWeekOfDay } from '../../controllers/overtimeController.js';

let managerToken: string;
let employeeToken: string;
let otherToken: string;
let employeeId: number | bigint;
let otherId: number | bigint;

// Smallest valid-looking JPEG payload: SOI marker + filler + EOI marker
const PHOTO = 'data:image/jpeg;base64,' + Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0xff, 0xd9]).toString('base64');

beforeAll(() => {
  initDb();
  const insert = db.prepare(`INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, 'x', ?)`);
  const managerId = insert.run('Baas', 'baas_ot@test.com', 'manager').lastInsertRowid;
  employeeId = insert.run('Werknemer', 'werknemer_ot@test.com', 'employee').lastInsertRowid;
  otherId = insert.run('Collega', 'collega_ot@test.com', 'employee').lastInsertRowid;
  const sign = (id: number | bigint, role: string) => jwt.sign({ id, role }, process.env.JWT_SECRET as string, { expiresIn: '1h' });
  managerToken = sign(managerId, 'manager');
  employeeToken = sign(employeeId, 'employee');
  otherToken = sign(otherId, 'employee');
});

afterEach(() => {
  const rows = db.prepare('SELECT photo_path FROM overtime_sessions WHERE photo_path IS NOT NULL').all() as { photo_path: string }[];
  for (const r of rows) fs.rmSync(path.join(PHOTO_DIR, r.photo_path), { force: true });
  db.exec('DELETE FROM overtime_sessions;');
});

afterAll(() => {
  db.close();
});

/**
 * @scenario Overuren: werknemer klokt in met foto en klokt uit; werkgever ziet, bekijkt en keurt goed.
 * @expectedLogic
 *   - Starten zonder geldige foto wordt geweigerd; een tweede start terwijl er een open registratie is geeft 409.
 *   - Alleen de manager ziet het teamoverzicht en kan beoordelen.
 *   - De foto is alleen zichtbaar voor de manager en de werknemer zelf.
 */
describe('Overtime API', () => {
  it('computes ISO weeks across a year boundary', () => {
    expect(isoWeekOfDay('2026-01-01')).toBe('2026-W01');
    expect(isoWeekOfDay('2027-01-01')).toBe('2026-W53');
    expect(isoWeekOfDay('2026-09-26')).toBe('2026-W39');
  });

  it('does not let the employer clock hours', async () => {
    const res = await request(app).post('/api/overtime/start').set('Authorization', `Bearer ${managerToken}`).send({ photo: PHOTO });
    expect(res.status).toBe(403);
  });

  it('rejects starting without a valid photo', async () => {
    const res = await request(app).post('/api/overtime/start').set('Authorization', `Bearer ${employeeToken}`).send({ photo: 'data:image/png;base64,AAAA' });
    expect(res.status).toBe(400);
  });

  it('runs the full clock-in, clock-out and review flow', async () => {
    const start = await request(app).post('/api/overtime/start').set('Authorization', `Bearer ${employeeToken}`).send({ photo: PHOTO });
    expect(start.status).toBe(201);
    const sessionId = start.body.sessionId;
    expect(start.body.current).toMatchObject({ id: sessionId, end_time: null, has_photo: 1, status: 'pending' });

    const again = await request(app).post('/api/overtime/start').set('Authorization', `Bearer ${employeeToken}`).send({ photo: PHOTO });
    expect(again.status).toBe(409);

    const stop = await request(app).post('/api/overtime/stop').set('Authorization', `Bearer ${employeeToken}`);
    expect(stop.status).toBe(200);
    expect(stop.body.session.end_time).not.toBeNull();

    const mine = await request(app).get('/api/overtime/me').set('Authorization', `Bearer ${employeeToken}`);
    expect(mine.body.current).toBeNull();
    expect(mine.body.sessions).toHaveLength(1);

    const forbiddenTeam = await request(app).get('/api/overtime/team').set('Authorization', `Bearer ${employeeToken}`);
    expect(forbiddenTeam.status).toBe(403);

    const team = await request(app).get('/api/overtime/team').set('Authorization', `Bearer ${managerToken}`);
    expect(team.status).toBe(200);
    const emp = team.body.employees.find((e: any) => e.id === Number(employeeId));
    expect(emp.sessions).toHaveLength(1);

    expect((await request(app).get(`/api/overtime/sessions/${sessionId}/photo`).set('Authorization', `Bearer ${managerToken}`)).status).toBe(200);
    expect((await request(app).get(`/api/overtime/sessions/${sessionId}/photo`).set('Authorization', `Bearer ${employeeToken}`)).status).toBe(200);
    expect((await request(app).get(`/api/overtime/sessions/${sessionId}/photo`).set('Authorization', `Bearer ${otherToken}`)).status).toBe(403);

    const forbiddenReview = await request(app).patch(`/api/overtime/sessions/${sessionId}/review`).set('Authorization', `Bearer ${employeeToken}`).send({ status: 'approved' });
    expect(forbiddenReview.status).toBe(403);

    const review = await request(app).patch(`/api/overtime/sessions/${sessionId}/review`).set('Authorization', `Bearer ${managerToken}`).send({ status: 'approved' });
    expect(review.status).toBe(200);
    expect(review.body.session.status).toBe('approved');

    // Only the employer can delete; the registration and its photo are gone afterwards
    expect((await request(app).delete(`/api/overtime/sessions/${sessionId}`).set('Authorization', `Bearer ${employeeToken}`)).status).toBe(403);
    const photoFile = (db.prepare('SELECT photo_path FROM overtime_sessions WHERE id = ?').get(sessionId) as { photo_path: string }).photo_path;
    const del = await request(app).delete(`/api/overtime/sessions/${sessionId}`).set('Authorization', `Bearer ${managerToken}`);
    expect(del.status).toBe(200);
    expect(db.prepare('SELECT 1 FROM overtime_sessions WHERE id = ?').get(sessionId)).toBeUndefined();
    await new Promise((r) => setTimeout(r, 50));
    expect(fs.existsSync(path.join(PHOTO_DIR, photoFile))).toBe(false);
  });

  it('lets only the manager create employees (max 5) who clock in with a personal code', async () => {
    const auth = (token: string) => ({ Authorization: `Bearer ${token}` });
    const add = (i: number, token = managerToken) =>
      request(app).post('/api/overtime/employees').set(auth(token)).send({ name: `Extra ${i}` });
    const codeLogin = (code: string) => request(app).post('/api/auth/code').send({ code });

    expect((await add(0, employeeToken)).status).toBe(403);

    // 2 employees exist already, so 3 more fit
    const created: any[] = [];
    for (let i = 1; i <= 3; i++) {
      const r = await add(i);
      expect(r.status).toBe(201);
      expect(r.body.code).toMatch(/^\d{6}$/);
      created.push(r.body);
    }
    const full = await add(4);
    expect(full.status).toBe(409);
    expect(full.body.error).toContain('maximaal 5');

    const list = await request(app).get('/api/overtime/employees').set(auth(managerToken));
    expect(list.body).toMatchObject({ max: 5, active: 5 });
    // The employer can see each employee's current code again later
    expect(list.body.employees.find((e: any) => e.id === created[0].employee.id).code).toBe(created[0].code);

    // The code logs the employee in and works for clocking
    const login = await codeLogin(created[0].code);
    expect(login.status).toBe(200);
    expect(login.body.user.name).toBe('Extra 1');
    expect((await request(app).get('/api/overtime/me').set(auth(login.body.token))).status).toBe(200);
    expect((await codeLogin('abc')).status).toBe(401);

    // A new code replaces the old one
    const renewed = await request(app).post(`/api/overtime/employees/${created[0].employee.id}/code`).set(auth(managerToken));
    expect(renewed.body.code).toMatch(/^\d{6}$/);
    if (renewed.body.code !== created[0].code) expect((await codeLogin(created[0].code)).status).toBe(401);
    expect((await codeLogin(renewed.body.code)).status).toBe(200);

    // Revoking access frees a spot and blocks the code
    const access = (id: number, active: boolean) =>
      request(app).patch(`/api/overtime/employees/${id}/access`).set(auth(managerToken)).send({ active });
    expect((await access(created[1].employee.id, false)).status).toBe(200);
    expect((await codeLogin(created[1].code)).status).toBe(403);
    expect((await add(4)).status).toBe(201);
    expect((await access(created[1].employee.id, true)).status).toBe(409);

    db.exec(`DELETE FROM profiles WHERE user_id IN (SELECT id FROM users WHERE name LIKE 'Extra %'); DELETE FROM users WHERE name LIKE 'Extra %';`);
  });

  it('refuses to stop when not clocked in', async () => {
    const res = await request(app).post('/api/overtime/stop').set('Authorization', `Bearer ${employeeToken}`);
    expect(res.status).toBe(409);
  });
});
