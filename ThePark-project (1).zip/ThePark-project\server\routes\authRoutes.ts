import { Router } from 'express';
import { login, logout } from '../controllers/authController.js';
import { loginWithCode } from '../controllers/teamController.js';
import { authenticate } from '../middlewares/authMiddleware.js';
// 🛡️ SECURITY: Rate limiters prevent brute force attacks
import { loginRateLimiter, codeRateLimiter } from '../middlewares/rateLimitMiddleware.js';

const router = Router();

// Apply rate limiting BEFORE the handler to block excess requests early
router.post('/login', loginRateLimiter, login);
router.post('/code', codeRateLimiter, loginWithCode);
router.post('/logout', authenticate, logout);

export default router;
