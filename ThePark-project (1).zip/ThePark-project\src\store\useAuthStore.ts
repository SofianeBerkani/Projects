import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  display_timezone?: string | null;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  serverTimeOffset: number;
  /** Signed in with a personal clock-in code: kept in memory only, never saved on the device. */
  viaCode: boolean;
  login: (user: User, token: string, serverTime?: string | number, viaCode?: boolean) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      serverTimeOffset: 0,
      viaCode: false,
      login: (user, token, serverTime, viaCode = false) => {
        let offset = 0;
        if (serverTime) {
          offset = new Date(serverTime).getTime() - Date.now();
        }
        set({ user, token, isAuthenticated: true, serverTimeOffset: offset, viaCode });
      },
      logout: () => set({ user: null, token: null, isAuthenticated: false, serverTimeOffset: 0, viaCode: false }),
    }),
    {
      name: 'thepark-auth-storage',
      // A code session must not survive a reload, so the next colleague starts at the code screen.
      partialize: (state) =>
        state.viaCode
          ? { user: null, token: null, isAuthenticated: false, serverTimeOffset: 0, viaCode: false }
          : state,
    }
  )
);
