import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import db from '../db/index.js';
import { AuthRequest } from '../middlewares/authMiddleware.js';
import { logAudit } from '../services/auditService.js';
import logger from '../utils/logger.js';

// Alleen de werkgever maakt accounts aan; er mogen maximaal MAX_EMPLOYEES werknemers tegelijk actief zijn.
export const MAX_EMPLOYEES = Number(process.env.MAX_EMPLOYEES) || 5;
const CODE_RE = /^\d{6}$/;
const JWT_SECRET = process.env.JWT_SECRET as string;

export const countActiveEmployees = (): number =>
    (db.prepare(`SELECT COUNT(*) AS c FROM users WHERE role = 'employee'`).get() as { c: number }).c;

const limitMessage = () => `Je kunt maximaal ${MAX_EMPLOYEES} werknemers tegelijk toegang geven.`;

// pin_hash (HMAC) is used to find the employee at login; pin_enc (AES-256-GCM) lets the employer see the code again.
const hashCode = (code: string) => crypto.createHmac('sha256', JWT_SECRET).update(`clock-code:${code}`).digest('hex');
const CODE_KEY = crypto.createHash('sha256').update(`clock-code-enc:${JWT_SECRET}`).digest();

const encryptCode = (code: string): string => {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', CODE_KEY, iv);
    const data = Buffer.concat([cipher.update(code, 'utf8'), cipher.final()]);
    return [iv, cipher.getAuthTag(), data].map((b) => b.toString('base64')).join('.');
};

const decryptCode = (stored: string | null): string | null => {
    if (!stored) return null;
    try {
        const [iv, tag, data] = stored.split('.').map((p) => Buffer.from(p, 'base64'));
        const decipher = crypto.createDecipheriv('aes-256-gcm', CODE_KEY, iv);
        decipher.setAuthTag(tag);
        return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
    } catch {
        // e.g. JWT_SECRET changed: the employer can simply make a new code
        return null;
    }
};

/** Picks a random 6-digit code no other account uses and stores it for the user. */
function assignNewCode(userId: number): string {
    const taken = db.prepare('SELECT 1 FROM users WHERE pin_hash = ?');
    for (;;) {
        const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
        const hash = hashCode(code);
        if (taken.get(hash)) continue;
        db.prepare('UPDATE users SET pin_hash = ?, pin_enc = ? WHERE id = ?').run(hash, encryptCode(code), userId);
        return code;
    }
}

// Non-manager accounts: 'employee' = has access, 'pending' = access revoked or never granted.
const listAccounts = () => db.prepare(`
    SELECT id, name, role, pin_hash IS NOT NULL AS has_code, pin_enc, created_at FROM users
    WHERE role IN ('employee', 'pending')
    ORDER BY role = 'pending', name COLLATE NOCASE
`).all() as { id: number; name: string; role: string; has_code: number; pin_enc: string | null; created_at: string }[];

const findAccount = (id: number) =>
    db.prepare(`SELECT id, name, role FROM users WHERE id = ? AND role IN ('employee', 'pending')`).get(id) as
        { id: number; name: string; role: string } | undefined;

export const getEmployees = (req: AuthRequest, res: Response): void => {
    try {
        const employees = listAccounts().map((a) => ({
            id: a.id, name: a.name, active: a.role === 'employee', hasCode: !!a.has_code, code: decryptCode(a.pin_enc),
        }));
        res.json({ max: MAX_EMPLOYEES, active: countActiveEmployees(), employees });
    } catch (error) {
        logger.error('Team list error:', error);
        res.status(500).json({ error: 'Er ging iets mis op de server.' });
    }
};

export const createEmployee = async (req: AuthRequest, res: Response): Promise<void> => {
    try {
        const name = String(req.body?.name || '').trim();
        if (!name || name.length > 80) {
            res.status(400).json({ error: 'Vul de naam van de werknemer in.' });
            return;
        }
        if (countActiveEmployees() >= MAX_EMPLOYEES) {
            res.status(409).json({ error: limitMessage() });
            return;
        }

        // Werknemers loggen alleen in met hun code; e-mail en wachtwoord zijn onbruikbare placeholders.
        const placeholderEmail = `werknemer-${crypto.randomUUID()}@thepark.local`;
        const placeholderHash = await bcrypt.hash(crypto.randomBytes(32).toString('hex'), 10);

        const result = db.transaction(() => {
            // Re-check inside the transaction so two quick requests can't exceed the limit.
            if (countActiveEmployees() >= MAX_EMPLOYEES) return null;
            const info = db.prepare(`INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'employee')`).run(name, placeholderEmail, placeholderHash);
            const id = Number(info.lastInsertRowid);
            db.prepare(`INSERT INTO profiles (user_id, status) VALUES (?, 'active')`).run(id);
            return { id, code: assignNewCode(id) };
        })();
        if (!result) {
            res.status(409).json({ error: limitMessage() });
            return;
        }

        logAudit('users', result.id, 'CREATE', req.user!.id, null, { name, role: 'employee' });
        res.status(201).json({ employee: { id: result.id, name, active: true, hasCode: true, code: result.code }, code: result.code });
    } catch (error) {
        logger.error('Team create error:', error);
        res.status(500).json({ error: 'Er ging iets mis op de server.' });
    }
};

export const newEmployeeCode = (req: AuthRequest, res: Response): void => {
    try {
        const account = findAccount(Number(req.params.id));
        if (!account) {
            res.status(404).json({ error: 'Werknemer niet gevonden.' });
            return;
        }
        const code = db.transaction(() => assignNewCode(account.id))();
        logAudit('users', account.id, 'RESET_CLOCK_CODE', req.user!.id, null, null);
        res.json({ code });
    } catch (error) {
        logger.error('Team code error:', error);
        res.status(500).json({ error: 'Er ging iets mis op de server.' });
    }
};

export const setEmployeeAccess = (req: AuthRequest, res: Response): void => {
    try {
        const account = findAccount(Number(req.params.id));
        if (!account) {
            res.status(404).json({ error: 'Werknemer niet gevonden.' });
            return;
        }
        const active = req.body?.active === true;

        const result = db.transaction(() => {
            if (active && account.role !== 'employee' && countActiveEmployees() >= MAX_EMPLOYEES) return 'limit';
            db.prepare('UPDATE users SET role = ? WHERE id = ?').run(active ? 'employee' : 'pending', account.id);
            db.prepare('UPDATE profiles SET status = ? WHERE user_id = ?').run(active ? 'active' : 'inactive', account.id);
            // Access revoked while clocked in: close the running registration now.
            if (!active) db.prepare('UPDATE overtime_sessions SET end_time = ? WHERE user_id = ? AND end_time IS NULL').run(new Date().toISOString(), account.id);
            return 'ok';
        })();
        if (result === 'limit') {
            res.status(409).json({ error: limitMessage() });
            return;
        }

        logAudit('users', account.id, 'UPDATE', req.user!.id, { role: account.role }, { role: active ? 'employee' : 'pending' });
        res.json({ employee: { id: account.id, name: account.name, active } });
    } catch (error) {
        logger.error('Team access error:', error);
        res.status(500).json({ error: 'Er ging iets mis op de server.' });
    }
};

/** Publiek: werknemer meldt zich aan met alleen zijn persoonlijke code. */
export const loginWithCode = (req: Request, res: Response): void => {
    try {
        const code = String(req.body?.code || '').trim();
        const user = CODE_RE.test(code)
            ? db.prepare(`SELECT id, name, role FROM users WHERE pin_hash = ?`).get(hashCode(code)) as { id: number; name: string; role: string } | undefined
            : undefined;
        if (!user) {
            res.status(401).json({ error: 'Deze code is niet bekend. Probeer het opnieuw.' });
            return;
        }
        if (user.role !== 'employee') {
            res.status(403).json({ error: 'Je hebt geen toegang meer. Vraag je werkgever om je toegang te geven.' });
            return;
        }
        // Short-lived: the app only keeps it in memory for one clock-in or clock-out.
        const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '12h' });
        logAudit('users', user.id, 'LOGIN', user.id, null, { method: 'clock_code' });
        res.json({ token, user: { id: user.id, name: user.name, email: '', role: user.role } });
    } catch (error) {
        logger.error('Code login error:', error);
        res.status(500).json({ error: 'Er ging iets mis op de server.' });
    }
};
