import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import api from '../../lib/axios';
import { useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '../../store/useAuthStore';
import {
  DAYS, MONTHS, MONTHS_LONG, addDays, dayKey, fmtDur, hm, isoWeek, mondayOf, sessMs, sumMs, toJpeg, weekRangeLabel,
  type OvertimeSession,
} from './overtimeUtils';

/** Current time, re-rendering every second so running timers tick. */
export function useNow(): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  return now;
}

// ---------- toast ----------
const ToastContext = createContext<(msg: string) => void>(() => {});
export const useToast = () => useContext(ToastContext);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState('');
  const [show, setShow] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout>>();
  const toast = useCallback((m: string) => {
    setMsg(m);
    setShow(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setShow(false), 3200);
  }, []);
  return (
    <ToastContext.Provider value={toast}>
      {children}
      <div className={`ot-toast${show ? ' show' : ''}`} role="status" aria-live="polite">{msg}</div>
    </ToastContext.Provider>
  );
}

// ---------- week ----------
export function useWeek() {
  const [monday, setMonday] = useState(() => mondayOf(new Date()));
  return { monday, week: isoWeek(monday), shift: (n: number) => setMonday((m) => addDays(m, 7 * n)) };
}

export function WeekNav({ monday, onShift, first }: { monday: Date; onShift: (n: number) => void; first?: boolean }) {
  const isNow = dayKey(monday) === dayKey(mondayOf(new Date()));
  return (
    <div className={`ot-weeknav${first ? ' first' : ''}`}>
      <button className="ot-navbtn" type="button" onClick={() => onShift(-1)} aria-label="Vorige week">‹</button>
      <h2>
        Week {Number(isoWeek(monday).split('-W')[1])}{isNow ? ' (deze week)' : ''}
        <span>{weekRangeLabel(monday)}</span>
      </h2>
      <button className="ot-navbtn" type="button" onClick={() => onShift(1)} aria-label="Volgende week">›</button>
    </div>
  );
}

export function DaysGrid({ monday, sessions, now }: { monday: Date; sessions: OvertimeSession[]; now: number }) {
  const today = dayKey(new Date(now));
  return (
    <div className="ot-days">
      {DAYS.map((label, i) => {
        const d = addDays(monday, i);
        const k = dayKey(d);
        const ms = sumMs(sessions.filter((s) => s.day === k), now);
        return (
          <div key={k} className={`ot-day${ms ? ' has' : ''}${k === today ? ' today' : ''}`}>
            <b>{label} {d.getDate()}</b>
            <span>{ms ? fmtDur(ms) : '–'}</span>
          </div>
        );
      })}
    </div>
  );
}

export function WeekTotals({ sessions, now }: { sessions: OvertimeSession[]; now: number }) {
  const approved = sessions.filter((s) => s.status === 'approved');
  return (
    <div className="ot-weektotal">
      <div>
        <div className="ot-sub">Totaal overuren</div>
        <strong>{fmtDur(sumMs(sessions, now))}</strong>
      </div>
      <div className="ot-sub">Goedgekeurd: <b>{fmtDur(sumMs(approved, now))}</b></div>
    </div>
  );
}

function Badge({ status }: { status: OvertimeSession['status'] }) {
  if (status === 'approved') return <span className="ot-badge ok">Goedgekeurd</span>;
  if (status === 'rejected') return <span className="ot-badge no">Afgekeurd</span>;
  return <span className="ot-badge">Te controleren</span>;
}

/** Deleting can't be undone, so the first tap only asks "Zeker verwijderen?" for a few seconds. */
function DeleteButton({ onConfirm }: { onConfirm: () => void }) {
  const [asking, setAsking] = useState(false);
  useEffect(() => {
    if (!asking) return;
    const t = setTimeout(() => setAsking(false), 4000);
    return () => clearTimeout(t);
  }, [asking]);
  return (
    <button
      type="button"
      className={`ot-delete${asking ? ' asking' : ''}`}
      onClick={() => (asking ? onConfirm() : setAsking(true))}
    >
      {asking ? 'Zeker verwijderen?' : 'Verwijderen'}
    </button>
  );
}

export function SessionList({
  sessions, now, onPhoto, onReview, onDelete,
}: {
  sessions: OvertimeSession[];
  now: number;
  onPhoto: (s: OvertimeSession) => void;
  onReview?: (s: OvertimeSession, status: 'approved' | 'rejected') => void;
  onDelete?: (s: OvertimeSession) => void;
}) {
  if (!sessions.length) return <p className="ot-empty">Nog geen overuren in deze week.</p>;
  const sorted = [...sessions].sort((a, b) => Date.parse(b.start_time) - Date.parse(a.start_time));
  return (
    <ul className="ot-sessions">
      {sorted.map((s) => {
        const sd = new Date(s.start_time);
        return (
          <li key={s.id} className="ot-sess">
            {s.has_photo ? (
              <button className="ot-thumb" type="button" onClick={() => onPhoto(s)} aria-label="Foto bekijken">
                <AuthPhoto sessionId={s.id} alt="" />
              </button>
            ) : (
              <span className="ot-thumb none">geen foto</span>
            )}
            <div>
              <div className="t">{hm(sd)} – {s.end_time ? hm(new Date(s.end_time)) : 'bezig'}</div>
              <div className="d">{DAYS[(sd.getDay() + 6) % 7]} {sd.getDate()} {MONTHS[sd.getMonth()]}</div>
              <Badge status={s.status} />
            </div>
            <div className="dur">{fmtDur(sessMs(s, now))}</div>
            {onReview && (
              <div className="ot-actions">
                <button type="button" className={s.status === 'approved' ? 'on-ok' : ''} aria-pressed={s.status === 'approved'} onClick={() => onReview(s, 'approved')}>
                  Goedkeuren
                </button>
                <button type="button" className={s.status === 'rejected' ? 'on-no' : ''} aria-pressed={s.status === 'rejected'} onClick={() => onReview(s, 'rejected')}>
                  Afkeuren
                </button>
                {onDelete && <DeleteButton onConfirm={() => onDelete(s)} />}
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}

// ---------- photos ----------
// Photos are behind authentication, so they're fetched with the token and shown as blob URLs.
const photoCache = new Map<number, Promise<string>>();
function loadPhoto(id: number): Promise<string> {
  let p = photoCache.get(id);
  if (!p) {
    p = api.get(`/overtime/sessions/${id}/photo`, { responseType: 'blob' }).then((r) => URL.createObjectURL(r.data));
    p.catch(() => photoCache.delete(id));
    photoCache.set(id, p);
  }
  return p;
}

export function clearPhotoCache() {
  for (const p of photoCache.values()) p.then(URL.revokeObjectURL, () => {});
  photoCache.clear();
}

export function AuthPhoto({ sessionId, alt, className }: { sessionId: number; alt: string; className?: string }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    loadPhoto(sessionId).then((u) => alive && setSrc(u)).catch(() => {});
    return () => { alive = false; };
  }, [sessionId]);
  return src ? <img src={src} alt={alt} className={className} /> : null;
}

function Dialog({ label, onClose, children }: { label: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="ot-dialog-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="ot-dialog" role="dialog" aria-modal="true" aria-label={label}>{children}</div>
    </div>
  );
}

export function PhotoDialog({ session, name, onClose }: { session: OvertimeSession; name?: string; onClose: () => void }) {
  const d = new Date(session.start_time);
  return (
    <Dialog label="Foto bekijken" onClose={onClose}>
      <AuthPhoto sessionId={session.id} alt="Foto bij inklokken" className="ot-bigphoto" />
      <p className="ot-note">
        {name ? `${name}, ` : ''}ingeklokt op {d.getDate()} {MONTHS_LONG[d.getMonth()]} om {hm(d)}
        {session.end_time ? `, uitgeklokt om ${hm(new Date(session.end_time))}.` : ', nog bezig.'}
      </p>
      <div className="ot-row">
        <button className="ot-btn primary" type="button" onClick={onClose}>Sluiten</button>
      </div>
    </Dialog>
  );
}

// ---------- camera ----------
export function CameraDialog({ onCancel, onConfirm }: { onCancel: () => void; onConfirm: (photo: string) => Promise<void> }) {
  const [mode, setMode] = useState<'starting' | 'live' | 'file' | 'preview'>('starting');
  const [photo, setPhoto] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopStream = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  };

  useEffect(() => {
    let cancelled = false;
    setMode('starting');
    setPhoto(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setMode('file');
      return;
    }
    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 } }, audio: false })
      .then((stream) => {
        if (cancelled) return stream.getTracks().forEach((t) => t.stop());
        streamRef.current = stream;
        setMode('live');
      })
      .catch(() => !cancelled && setMode('file'));
    return () => {
      cancelled = true;
      stopStream();
    };
  }, [attempt]);

  useEffect(() => {
    if (mode === 'live' && videoRef.current && streamRef.current) videoRef.current.srcObject = streamRef.current;
  }, [mode]);

  const snap = () => {
    const v = videoRef.current;
    if (!v || !v.videoWidth) return;
    setPhoto(toJpeg(v, v.videoWidth, v.videoHeight, true));
    stopStream();
    setMode('preview');
  };

  const onFile = (file?: File) => {
    if (!file) return;
    const img = new Image();
    img.onload = () => {
      setPhoto(toJpeg(img, img.naturalWidth, img.naturalHeight, false));
      URL.revokeObjectURL(img.src);
      setMode('preview');
    };
    img.src = URL.createObjectURL(file);
  };

  const go = async () => {
    if (!photo) return;
    setBusy(true);
    try {
      await onConfirm(photo);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog label="Foto maken" onClose={onCancel}>
      <h3>Even lachen</h3>
      <div className="ot-cam">
        {mode === 'starting' && <span>Camera starten…</span>}
        {mode === 'live' && <video ref={videoRef} autoPlay playsInline muted />}
        {mode === 'file' && <span style={{ padding: '1rem' }}>Tik op “Foto maken” om je camera te openen.</span>}
        {mode === 'preview' && photo && <img src={photo} alt="Voorbeeld van je foto" />}
      </div>
      <p className="ot-note">Je leidinggevende ziet deze foto bij je uren.</p>
      <div className="ot-row">
        {mode === 'preview' ? (
          <>
            <button className="ot-btn" type="button" onClick={() => setAttempt((a) => a + 1)} disabled={busy}>Opnieuw</button>
            <button className="ot-btn primary" type="button" onClick={go} disabled={busy}>Start met werken</button>
          </>
        ) : (
          <>
            <button className="ot-btn" type="button" onClick={onCancel}>Annuleren</button>
            {mode === 'file' ? (
              <span className="ot-btn primary ot-filebtn">
                Foto maken
                <input type="file" accept="image/*" capture="user" onChange={(e) => onFile(e.target.files?.[0])} />
              </span>
            ) : (
              <button className="ot-btn primary" type="button" onClick={snap} disabled={mode !== 'live'}>Maak foto</button>
            )}
          </>
        )}
      </div>
    </Dialog>
  );
}

export const apiError = (e: any, fallback: string) => e?.response?.data?.error || fallback;

/** Ends the session and wipes cached data and photos, so the next person on this phone sees nothing of the previous one. */
export function useSignOut() {
  const queryClient = useQueryClient();
  const logout = useAuthStore((s) => s.logout);
  return useCallback(() => {
    clearPhotoCache();
    queryClient.clear();
    logout();
  }, [queryClient, logout]);
}
