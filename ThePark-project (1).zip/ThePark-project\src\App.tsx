/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAppStore } from './store/useAppStore';
import { useAuthStore } from './store/useAuthStore';
import Login from './features/auth/Login';
import ProtectedRoute from './components/ProtectedRoute';
import OvertimeLayout from './features/overtime/OvertimeLayout';
import MyHours from './features/overtime/MyHours';
import TeamOverview from './features/overtime/TeamOverview';
import Employees from './features/overtime/Employees';

// De oude HR-schermen (Engels/Arabisch) staan nog in src/features/, maar zijn niet meer
// bereikbaar: deze app is alleen de Nederlandstalige overuren-app.

// Werkgever ziet eerst het overzicht van alle werknemers, een werknemer meteen de stempelklok.
function OvertimeHome() {
  const role = useAuthStore((state) => state.user?.role);
  return role === 'manager' ? <TeamOverview /> : <MyHours />;
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function AppContent() {
  const theme = useAppStore((state) => state.theme);

  // Light (white) by default, dark when chosen; the app is always Dutch and left-to-right.
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
    root.dir = 'ltr';
    root.lang = 'nl';
  }, [theme]);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <ProtectedRoute roles={['manager', 'employee']}>
              <OvertimeLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<OvertimeHome />} />
          <Route
            path="werknemers"
            element={
              <ProtectedRoute roles={['manager']}>
                <Employees />
              </ProtectedRoute>
            }
          />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
    </QueryClientProvider>
  );
}
