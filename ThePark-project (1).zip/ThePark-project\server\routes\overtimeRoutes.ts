import { Router } from 'express';
import { getMine, startWork, stopWork, getTeam, reviewSession, deleteSession, getPhoto } from '../controllers/overtimeController.js';
import { getEmployees, createEmployee, setEmployeeAccess, newEmployeeCode } from '../controllers/teamController.js';
import { authenticate, requireRole } from '../middlewares/authMiddleware.js';

const router = Router();

router.use(authenticate, requireRole(['employee', 'manager']));

// Alleen werknemers klokken; de werkgever controleert alleen
router.get('/me', requireRole(['employee']), getMine);
router.post('/start', requireRole(['employee']), startWork);
router.post('/stop', requireRole(['employee']), stopWork);
router.get('/sessions/:id/photo', getPhoto); // werkgever + de werknemer zelf

// Alleen de werkgever
router.get('/team', requireRole(['manager']), getTeam);
router.patch('/sessions/:id/review', requireRole(['manager']), reviewSession);
router.delete('/sessions/:id', requireRole(['manager']), deleteSession);
router.get('/employees', requireRole(['manager']), getEmployees);
router.post('/employees', requireRole(['manager']), createEmployee);
router.patch('/employees/:id/access', requireRole(['manager']), setEmployeeAccess);
router.post('/employees/:id/code', requireRole(['manager']), newEmployeeCode);

export default router;
