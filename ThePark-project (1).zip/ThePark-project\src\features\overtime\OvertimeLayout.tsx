import { useEffect, type ReactNode } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useAuthStore } from '../../store/useAuthStore';
import { useAppStore } from '../../store/useAppStore';
import { ToastProvider, useSignOut } from './components';
import './overtime.css';

/** Na zoveel tijd zonder aanraken gaat een code-sessie terug naar het codescherm. */
const CODE_IDLE_MS = 90_000;

export function ParkHeader({ children }: { children?: ReactNode }) {
  return (
    <>
      <img className="ot-logo" alt="The Park" src="/thepark-logo.svg" />
      <h1 className="ot-brand">ThePark<span>Overuren</span></h1>
      {children}
    </>
  );
}

export default function OvertimeLayout() {
  const { user, viaCode } = useAuthStore();
  const { theme, toggleTheme } = useAppStore();
  const signOut = useSignOut();
  const isManager = user?.role === 'manager';

  useEffect(() => {
    if (!viaCode) return;
    let timer = setTimeout(signOut, CODE_IDLE_MS);
    const reset = () => {
      clearTimeout(timer);
      timer = setTimeout(signOut, CODE_IDLE_MS);
    };
    const events = ['pointerdown', 'keydown', 'scroll'] as const;
    events.forEach((e) => window.addEventListener(e, reset, { passive: true }));
    return () => {
      clearTimeout(timer);
      events.forEach((e) => window.removeEventListener(e, reset));
    };
  }, [viaCode, signOut]);

  return (
    <div className="ot">
      <ToastProvider>
        <header className="ot-top">
          <div className={`ot-top-in${isManager ? '' : ' no-tabs'}`}>
            <ParkHeader>
              <div className="ot-user">
                <span>{user?.name}</span>
                <button className="ot-iconbtn" type="button" onClick={toggleTheme} aria-label={theme === "light" ? "Donker thema" : "Licht thema"}>
                  {theme === "light" ? "☾" : "☀"}
                </button>
                <button className="ot-iconbtn" type="button" onClick={signOut}>{viaCode ? 'Klaar' : 'Uitloggen'}</button>
              </div>
            </ParkHeader>
            {isManager && (
              <nav className="ot-tabs">
                <NavLink to="/" end>Overzicht werknemers</NavLink>
                <NavLink to="/werknemers">Werknemers</NavLink>
              </nav>
            )}
          </div>
        </header>
        <main className="ot-wrap">
          {viaCode && <p className="ot-hello">Hoi {user?.name}!</p>}
          <Outlet />
        </main>
      </ToastProvider>
    </div>
  );
}
