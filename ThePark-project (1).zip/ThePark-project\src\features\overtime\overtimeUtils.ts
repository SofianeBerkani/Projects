export interface OvertimeSession {
  id: number;
  user_id: number;
  start_time: string;
  end_time: string | null;
  day: string;
  week: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewed_at: string | null;
  has_photo: 0 | 1;
}

export interface TeamMember {
  id: number;
  name: string;
  openSince: string | null;
  sessions: OvertimeSession[];
}

export const DAYS = ['ma', 'di', 'wo', 'do', 'vr', 'za', 'zo'];
export const WEEKDAYS_LONG = ['Zondag', 'Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag'];
export const MONTHS = ['jan', 'feb', 'mrt', 'apr', 'mei', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dec'];
export const MONTHS_LONG = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];

const pad = (n: number) => String(n).padStart(2, '0');

export const dayKey = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export function isoWeek(d: Date): string {
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const wd = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - wd);
  const y = t.getUTCFullYear();
  return `${y}-W${pad(Math.ceil(((t.getTime() - Date.UTC(y, 0, 1)) / 864e5 + 1) / 7))}`;
}

export function mondayOf(d: Date): Date {
  const m = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  m.setDate(m.getDate() - ((m.getDay() || 7) - 1));
  return m;
}

export const addDays = (d: Date, n: number) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};

export const hm = (d: Date) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;

export function fmtClock(ms: number): string {
  const s = Math.floor(Math.max(0, ms) / 1000);
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor(s / 60) % 60)}:${pad(s % 60)}`;
}

export function fmtDur(ms: number): string {
  const m = Math.round(Math.max(0, ms) / 60000);
  return `${Math.floor(m / 60)}u ${pad(m % 60)}m`;
}

export const sessMs = (s: OvertimeSession, now: number) =>
  (s.end_time ? Date.parse(s.end_time) : now) - Date.parse(s.start_time);

export const sumMs = (list: OvertimeSession[], now: number) => list.reduce((a, s) => a + sessMs(s, now), 0);

export function weekRangeLabel(monday: Date): string {
  const sun = addDays(monday, 6);
  return monday.getMonth() === sun.getMonth()
    ? `${monday.getDate()} t/m ${sun.getDate()} ${MONTHS_LONG[sun.getMonth()]}`
    : `${monday.getDate()} ${MONTHS_LONG[monday.getMonth()]} t/m ${sun.getDate()} ${MONTHS_LONG[sun.getMonth()]}`;
}

/** Downscale to a small JPEG so a clock-in photo stays ~30-60 KB. */
export function toJpeg(source: CanvasImageSource, w: number, h: number, mirror: boolean): string {
  const W = 420;
  const H = Math.round((W * h) / w);
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const ctx = c.getContext('2d')!;
  if (mirror) {
    ctx.translate(W, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(source, 0, 0, W, H);
  return c.toDataURL('image/jpeg', 0.72);
}
