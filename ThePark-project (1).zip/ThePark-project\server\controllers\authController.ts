import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../db/index.js';
import { logAudit } from '../services/auditService.js';
import { AuthRequest } from '../middlewares/authMiddleware.js';
import logger from '../utils/logger.js';

// 🛡️ Sentinel: Enforce secure JWT Secret from environment variables.
// Do not use hardcoded fallbacks that could be exploited if env vars are missing.
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
    throw new Error('CRITICAL SECURITY CONFIGURATION: JWT_SECRET environment variable is missing.');
}

/** Werkgever logt in met e-mail en wachtwoord. Werknemers gebruiken hun persoonlijke code (zie teamController). */
export const login = async (req: Request, res: Response): Promise<void> => {
    try {
        const { email, password } = req.body || {};
        if (!email || !password) {
            res.status(400).json({ error: 'Vul je e-mail en wachtwoord in.' });
            return;
        }

        const normalizedEmail = String(email).toLowerCase();
        const user = db.prepare('SELECT id, name, email, role, password_hash FROM users WHERE LOWER(email) = ?').get(normalizedEmail) as
            { id: number; name: string; email: string; role: string; password_hash: string } | undefined;

        // Same answer for unknown e-mail and wrong password, so nobody can probe which accounts exist.
        if (!user || !(await bcrypt.compare(String(password), user.password_hash))) {
            res.status(401).json({ error: 'E-mail of wachtwoord is niet juist.' });
            return;
        }
        if (user.role !== 'manager') {
            res.status(403).json({ error: 'Werknemers loggen in met hun persoonlijke code.' });
            return;
        }

        const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
        logAudit('users', user.id, 'LOGIN', user.id, null, { email: normalizedEmail });

        res.json({
            token,
            user: { id: user.id, name: user.name, email: user.email, role: user.role },
        });
    } catch (error) {
        logger.error('Login error:', error);
        res.status(500).json({ error: 'Er ging iets mis op de server.' });
    }
};

export const logout = async (req: AuthRequest, res: Response): Promise<void> => {
    try {
        const userId = req.user!.id;
        logAudit('users', userId, 'LOGOUT', userId, null, null);
        res.json({ message: 'Uitgelogd.' });
    } catch (error) {
        logger.error('Logout error:', error);
        res.status(500).json({ error: 'Er ging iets mis op de server.' });
    }
};
